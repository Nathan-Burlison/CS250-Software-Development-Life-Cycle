import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.URI;
import java.net.URL;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListCellRenderer;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.WindowConstants;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

/**
 * CS 250 - SNHU Travel
 * User Story 1: Top Five Destination List
 *
 * This program displays five travel destinations in ranked order. Each row
 * contains a destination image, short description, and a clickable travel
 * package link. The window also includes a custom color scheme and student
 * name label to meet the assignment requirements.
 *
 * @author Nathan Burlison
 */
public class TopFiveDestinationList {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                TopDestinationListFrame frame = new TopDestinationListFrame();
                frame.setVisible(true);
            }
        });
    }
}

/**
 * Main application window for the Top Five Destination List.
 */
class TopDestinationListFrame extends JFrame {
    private static final long serialVersionUID = 1L;

    private static final Color NAVY = new Color(31, 56, 82);
    private static final Color LIGHT_BLUE = new Color(228, 239, 248);
    private static final Color LINK_BLUE = new Color(20, 90, 170);

    private final DefaultListModel<TextAndIcon> listModel;
    private final JList<TextAndIcon> destinationList;

    public TopDestinationListFrame() {
        super("SNHU Travel - Top Five Destinations");

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(980, 860);
        setMinimumSize(new Dimension(820, 700));
        setLocationRelativeTo(null);

        listModel = new DefaultListModel<TextAndIcon>();

        // User Story 1: Add the five destinations in ranked order.
        // Each item contains a name, one-sentence description, picture, and package link.
        addDestination(
                1,
                "Paris, France",
                "Famous for the Eiffel Tower, art museums, sidewalk cafes, and classic European architecture.",
                "/resources/Paris.png",
                "https://www.expedia.com/Paris.d179898.Destination-Travel-Guides");

        addDestination(
                2,
                "Bali, Indonesia",
                "A tropical island known for beaches, temples, rice terraces, and a relaxed cultural atmosphere.",
                "/resources/Bali.png",
                "https://www.expedia.com/Bali.d602651.Destination-Travel-Guides");

        addDestination(
                3,
                "Tokyo, Japan",
                "A fast-paced city that blends modern technology and entertainment with temples and long-standing traditions.",
                "/resources/Tokyo.png",
                "https://www.expedia.com/Tokyo.d179900.Destination-Travel-Guides");

        addDestination(
                4,
                "Rome, Italy",
                "The Eternal City offers ancient landmarks, historic neighborhoods, Italian food, and centuries of art.",
                "/resources/Rome.png",
                "https://www.expedia.com/Rome.d179899.Destination-Travel-Guides");

        addDestination(
                5,
                "New York City, USA",
                "A major travel destination filled with iconic landmarks, Broadway, museums, shopping, and diverse neighborhoods.",
                "/resources/NewYork.png",
                "https://www.expedia.com/New-York.d178293.Destination-Travel-Guides");

        destinationList = new JList<TextAndIcon>(listModel);
        destinationList.setCellRenderer(new TextAndIconListCellRenderer(12));
        destinationList.setFixedCellHeight(150);
        destinationList.setSelectionBackground(new Color(196, 220, 239));
        destinationList.setSelectionForeground(Color.BLACK);
        destinationList.setBackground(Color.WHITE);
        destinationList.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        destinationList.setToolTipText("Click a destination to open its travel package page.");

        // Clicking a list item opens that destination's package page in the default browser.
        destinationList.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent event) {
                if (event.getClickCount() == 1) {
                    openSelectedPackage(event.getPoint());
                }
            }
        });

        JScrollPane scrollPane = new JScrollPane(destinationList);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(createHeaderPanel(), BorderLayout.NORTH);
        getContentPane().add(scrollPane, BorderLayout.CENTER);
        getContentPane().add(createFooterPanel(), BorderLayout.SOUTH);
    }

    /**
     * Creates the customized header used above the list.
     */
    private JPanel createHeaderPanel() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(NAVY);
        header.setBorder(new EmptyBorder(16, 22, 16, 22));

        JLabel title = new JLabel("SNHU Travel - Top Five Destinations");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("SansSerif", Font.BOLD, 25));

        JLabel subtitle = new JLabel("Select a destination to view its featured vacation-package page.");
        subtitle.setForeground(new Color(222, 233, 243));
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 14));

        JPanel textPanel = new JPanel(new BorderLayout(0, 5));
        textPanel.setOpaque(false);
        textPanel.add(title, BorderLayout.NORTH);
        textPanel.add(subtitle, BorderLayout.SOUTH);

        // Required assignment customization: label containing the student's name.
        JLabel studentName = new JLabel("Created by Nathan Burlison");
        studentName.setForeground(Color.WHITE);
        studentName.setFont(new Font("SansSerif", Font.BOLD, 14));
        studentName.setHorizontalAlignment(SwingConstants.RIGHT);

        header.add(textPanel, BorderLayout.CENTER);
        header.add(studentName, BorderLayout.EAST);
        return header;
    }

    /**
     * Adds a small footer explaining the source of the custom graphics.
     */
    private JPanel createFooterPanel() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(LIGHT_BLUE);
        footer.setBorder(new EmptyBorder(8, 16, 8, 16));

        JLabel note = new JLabel(
                "Destination graphics were created specifically for this CS 250 project. Travel package links open Expedia.");
        note.setFont(new Font("SansSerif", Font.PLAIN, 12));
        note.setForeground(new Color(55, 65, 75));
        footer.add(note, BorderLayout.CENTER);
        return footer;
    }

    /**
     * Adds one destination to the list model.
     */
    private void addDestination(int rank, String name, String description, String imagePath, String packageUrl) {
        Icon icon = loadScaledIcon(imagePath);
        listModel.addElement(new TextAndIcon(rank, name, description, icon, packageUrl));
    }

    /**
     * Loads an image from the resources folder and scales it to a consistent size.
     */
    private Icon loadScaledIcon(String resourcePath) {
        URL resource = getClass().getResource(resourcePath);

        if (resource == null) {
            // A visible fallback keeps the program running if an image is accidentally omitted.
            return UIManager.getIcon("OptionPane.informationIcon");
        }

        ImageIcon original = new ImageIcon(resource);
        Image scaled = original.getImage().getScaledInstance(220, 128, Image.SCALE_SMOOTH);
        return new ImageIcon(scaled);
    }

    /**
     * Opens the package URL associated with the clicked destination.
     */
    private void openSelectedPackage(Point clickPoint) {
        int index = destinationList.locationToIndex(clickPoint);
        if (index < 0) {
            return;
        }

        Rectangle bounds = destinationList.getCellBounds(index, index);
        if (bounds == null || !bounds.contains(clickPoint)) {
            return;
        }

        TextAndIcon selectedDestination = listModel.getElementAt(index);

        try {
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                Desktop.getDesktop().browse(new URI(selectedDestination.getPackageUrl()));
            } else {
                JOptionPane.showMessageDialog(
                        this,
                        selectedDestination.getPackageUrl(),
                        "Travel Package Link",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception exception) {
            JOptionPane.showMessageDialog(
                    this,
                    "The travel package page could not be opened.\n" + selectedDestination.getPackageUrl(),
                    "Unable to Open Link",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Returns the hyperlink color used by the renderer.
     */
    public static Color getLinkBlue() {
        return LINK_BLUE;
    }
}

/**
 * Stores all information needed to render and open one destination entry.
 */
class TextAndIcon {
    private final int rank;
    private final String name;
    private final String description;
    private final Icon icon;
    private final String packageUrl;

    public TextAndIcon(int rank, String name, String description, Icon icon, String packageUrl) {
        this.rank = rank;
        this.name = name;
        this.description = description;
        this.icon = icon;
        this.packageUrl = packageUrl;
    }

    public int getRank() {
        return rank;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public Icon getIcon() {
        return icon;
    }

    public String getPackageUrl() {
        return packageUrl;
    }
}

/**
 * Custom list-cell renderer that shows the image, description, and hyperlink text.
 */
class TextAndIconListCellRenderer extends JLabel implements ListCellRenderer<TextAndIcon> {
    private static final long serialVersionUID = 1L;
    private static final Border NO_FOCUS_BORDER = new EmptyBorder(1, 1, 1, 1);

    private final Border insideBorder;

    public TextAndIconListCellRenderer(int padding) {
        insideBorder = BorderFactory.createEmptyBorder(padding, padding, padding, padding);
        setOpaque(true);
        setIconTextGap(18);
        setVerticalAlignment(SwingConstants.CENTER);
    }

    @Override
    public Component getListCellRendererComponent(
            JList<? extends TextAndIcon> list,
            TextAndIcon value,
            int index,
            boolean isSelected,
            boolean hasFocus) {

        // HTML lets the label show a bold title, description, and underlined link text.
        String linkColor = toHtmlColor(TopDestinationListFrame.getLinkBlue());
        String html = "<html><div style='width:560px;'>"
                + "<span style='font-size:16px;'><b>" + value.getRank() + ". " + value.getName() + "</b></span><br>"
                + "<span style='font-size:12px;'>" + value.getDescription() + "</span><br><br>"
                + "<span style='color:" + linkColor + ";'><u>View featured travel package for "
                + value.getName() + "</u></span>"
                + "</div></html>";

        setText(html);
        setIcon(value.getIcon());

        if (isSelected) {
            setBackground(list.getSelectionBackground());
            setForeground(list.getSelectionForeground());
        } else {
            // Alternating row shading is an additional visual customization.
            setBackground(index % 2 == 0 ? Color.WHITE : new Color(244, 248, 251));
            setForeground(list.getForeground());
        }

        Border outsideBorder = hasFocus
                ? UIManager.getBorder("List.focusCellHighlightBorder")
                : NO_FOCUS_BORDER;

        Border rowSeparator = BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(215, 223, 230));
        Border combinedInside = BorderFactory.createCompoundBorder(rowSeparator, insideBorder);
        setBorder(BorderFactory.createCompoundBorder(outsideBorder, combinedInside));
        setComponentOrientation(list.getComponentOrientation());
        setEnabled(list.isEnabled());
        setFont(new Font("SansSerif", Font.PLAIN, 14));
        setPreferredSize(new Dimension(900, 150));

        return this;
    }

    private String toHtmlColor(Color color) {
        return String.format("#%02x%02x%02x", color.getRed(), color.getGreen(), color.getBlue());
    }

    // Empty overrides improve renderer performance because Swing reuses the component.
    @Override public void validate() { }
    @Override public void invalidate() { }
    @Override public void repaint() { }
    @Override public void revalidate() { }
    @Override public void repaint(long tm, int x, int y, int width, int height) { }
    @Override public void repaint(Rectangle rectangle) { }
}
