CS 250 - SNHU Travel
User Story 1: Top Five Destination List
Student: Nathan Burlison

WHAT WAS CHANGED
- Replaced the five placeholder entries with Paris, Bali, Tokyo, Rome, and New York City.
- Added a one-sentence description for every destination.
- Added a unique destination image for every list item.
- Replaced the original image set with new custom destination illustrations featuring different scenery and layouts.
- Added clickable travel-package text for every destination. Clicking a row opens the package page in the default web browser.
- Added a custom navy/light-blue color scheme, larger title, alternating row shading, and consistent image sizing.
- Added the required student-name label.
- Added clear code comments and an image-credit file.

RUNNING IN ECLIPSE
1. Import the project into Eclipse.
2. Open src/TopFiveDestinationList.java.
3. Run TopFiveDestinationList as a Java Application.
4. Click any destination row to open its package page.

RUNNABLE JAR
The submission package also includes Nathan_Burlison_TopFiveDestinations.jar.
