import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Color;

public class SlideShow extends JFrame {

    // Declare the Swing components used by the slide show.
    private JPanel slidePane;
    private JPanel textPane;
    private JPanel buttonPane;
    private JPanel bottomPane;
    private CardLayout card;
    private CardLayout cardText;
    private JButton btnPrev;
    private JButton btnNext;
    private JLabel lblSlide;
    private JLabel lblTextArea;

    /**
     * Create the application.
     */
    public SlideShow() throws HeadlessException {
        initComponent();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initComponent() {
        // Initialize the layouts and panels used to display each image and caption.
        card = new CardLayout();
        cardText = new CardLayout();
        slidePane = new JPanel();
        textPane = new JPanel();
        textPane.setBackground(Color.BLUE);
        textPane.setBounds(5, 470, 790, 50);
        textPane.setVisible(true);
        buttonPane = new JPanel();
        bottomPane = new JPanel(new BorderLayout());
        btnPrev = new JButton();
        btnNext = new JButton();
        lblSlide = new JLabel();
        lblTextArea = new JLabel();

        // Keep the original slide-show design, but update the title to match the
        // Product Owner's new detox/wellness travel focus.
        setSize(820, 650);
        setLocationRelativeTo(null);
        setTitle("Top 5 Wellness Destinations SlideShow");
        getContentPane().setLayout(new BorderLayout(10, 50));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Use CardLayout so each destination image stays synchronized with its caption.
        slidePane.setLayout(card);
        textPane.setLayout(cardText);

        // Build five cards because the existing feature is still a Top Five list.
        // Only the content is changing to meet the Product Owner's new priority.
        for (int i = 1; i <= 5; i++) {
            lblSlide = new JLabel();
            lblTextArea = new JLabel();
            lblTextArea.setForeground(Color.WHITE);
            lblSlide.setText(getResizeIcon(i));
            lblTextArea.setText(getTextDescription(i));
            slidePane.add(lblSlide, "card" + i);
            textPane.add(lblTextArea, "cardText" + i);
        }

        getContentPane().add(slidePane, BorderLayout.CENTER);

        buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));

        btnPrev.setText("Previous");
        btnPrev.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                goPrevious();
            }
        });
        buttonPane.add(btnPrev);

        btnNext.setText("Next");
        btnNext.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                goNext();
            }
        });
        buttonPane.add(btnNext);

        // Place the caption and navigation controls in one bottom panel. This keeps
        // the updated wellness text visible while preserving the original buttons.
        bottomPane.add(textPane, BorderLayout.CENTER);
        bottomPane.add(buttonPane, BorderLayout.SOUTH);
        getContentPane().add(bottomPane, BorderLayout.SOUTH);
    }

    /**
     * Display the previous image and matching description.
     */
    private void goPrevious() {
        card.previous(slidePane);
        cardText.previous(textPane);
    }

    /**
     * Display the next image and matching description.
     */
    private void goNext() {
        card.next(slidePane);
        cardText.next(textPane);
    }

    /**
     * Return the wellness image assigned to the requested slide.
     * The resource paths were updated so all five pictures support the Product
     * Owner's new wellness-travel requirement while preserving the original control.
     */
    private String getResizeIcon(int i) {
        String image = "";
        if (i == 1) {
            image = "<html><body><img width='800' height='500' src='" + getClass().getResource("/resources/Wellness1.jpg") + "'></body></html>";
        } else if (i == 2) {
            image = "<html><body><img width='800' height='500' src='" + getClass().getResource("/resources/Wellness2.jpg") + "'></body></html>";
        } else if (i == 3) {
            image = "<html><body><img width='800' height='500' src='" + getClass().getResource("/resources/Wellness3.jpg") + "'></body></html>";
        } else if (i == 4) {
            image = "<html><body><img width='800' height='500' src='" + getClass().getResource("/resources/Wellness4.jpg") + "'></body></html>";
        } else if (i == 5) {
            image = "<html><body><img width='800' height='500' src='" + getClass().getResource("/resources/Wellness5.jpg") + "'></body></html>";
        }
        return image;
    }

    /**
     * Return the updated destination text for each slide.
     * These descriptions replace the general-travel placeholders with wellness-
     * focused content requested by the Product Owner.
     */
    private String getTextDescription(int i) {
        String text = "";
        if (i == 1) {
            text = "<html><body><font size='5'>#1 Sedona, Arizona.</font><br>Red-rock scenery, spa retreats, yoga, and outdoor activities create a relaxing wellness escape.</body></html>";
        } else if (i == 2) {
            text = "<html><body><font size='5'>#2 Calistoga, California.</font><br>Geothermal hot springs, mineral pools, and spa experiences make this Napa Valley town ideal for unwinding.</body></html>";
        } else if (i == 3) {
            text = "<html><body><font size='5'>#3 Desert Hot Springs, California.</font><br>Natural mineral springs, desert views, and quiet spa resorts offer a restorative getaway.</body></html>";
        } else if (i == 4) {
            text = "<html><body><font size='5'>#4 Asheville, North Carolina.</font><br>Blue Ridge scenery, hiking, yoga, and a varied spa scene support a peaceful mountain retreat.</body></html>";
        } else if (i == 5) {
            text = "<html><body><font size='5'>#5 Hot Springs, Arkansas.</font><br>Historic Bathhouse Row, thermal waters, and Ouachita Mountain trails combine wellness with outdoor recreation.</body></html>";
        }
        return text;
    }

    /**
     * Launch the application on the Swing event-dispatch thread.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                SlideShow ss = new SlideShow();
                ss.setVisible(true);
            }
        });
    }
}
